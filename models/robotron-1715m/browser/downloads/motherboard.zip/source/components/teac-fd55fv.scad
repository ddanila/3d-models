// FD-55-family envelope reference, refined from Danila's two actual drives.
// Photos 20250212: K5601 / TEAC 15532064-00A and Ratan / 15532092-00A.
// Envelope 146 x 203 x 41.3 mm remains the TEAC drawing reference, not a measurement.
// Local front-left-bottom; x increases to the right when facing the computer.
teac_width=146; teac_depth=203; teac_height=41.3;
module teac_frame() {
    difference() {
        union() {
            cube([146,203,2]);
            for(x=[0,143])translate([x,0,0])cube([3,203,34]);
            translate([0,200,12])cube([146,3,26]);
            translate([4,4,28])cube([138,42,1.2]);
            translate([4,48,25])cube([138,2,7]);
            for(x=[5,133],y=[10,180])translate([x,y,2])cube([8,10,29]);
        }
        translate([70,64,-1])cylinder(d=78,h=4,$fn=64);
        translate([45,106,-1])cube([52,81,4]);
        for(x=[-1,142],y=[46,125])translate([x,y,16])rotate([0,90,0])cylinder(d=3,h=6,$fn=16);
        translate([119,199,23])rotate([-90,0,0])cylinder(d=5,h=5,$fn=20);
    }
    translate([4,50,24])difference(){cube([138,147,1.2]);
        translate([39,26,-1])cube([53,112,4]);
        translate([99,79,-1])cube([40,64,4]);
        translate([-1,81,-1])cube([31,62,4]);}
}
module teac_mechanism() {
    translate([70,64,2])cylinder(d=76,h=6,$fn=48);
    // Central slotted stamped bridge and spindle clamp.
    translate([52,48,31])difference(){cube([36,145,2]);
        translate([5,50,-1])cube([26,74,4]);
        translate([18,45,-1])cylinder(d=26,h=4,$fn=40);
        translate([18,137,-1])cylinder(d=11,h=4,$fn=24);}

    for(x=[46,92])translate([x,78,18])rotate([-90,0,0])cylinder(d=3,h=108,$fn=16);
    // Fixed rail saddles stay outside the full 35 mm carriage travel.
    for(x=[46,92],y=[80,181])translate([x,y,18])difference(){
        translate([-4,-3,-5])cube([8,6,9]);
        rotate([90,0,0])cylinder(d=3.1,h=8,center=true,$fn=20);
    }

    translate([109,158,14])rotate([0,90,0])cylinder(d=18,h=8,$fn=32);
    // Fixed journals for the separate operating shaft.
    for(y=[3,42])translate([118,y,32])rotate([90,0,0])difference(){
        cylinder(d=7,h=3,center=true,$fn=24);cylinder(d=3.3,h=4,center=true,$fn=24);
    }

    for(x=[8,137],y=[12,95,190])translate([x,y,32])cylinder(d=5,h=1.5,$fn=20);
}
module teac_black() {
    translate([113,133,12])cube([25,46,23]); // laminated stepper body

    translate([11,166,11])cube([18,14,13]);
    for(p=[[43,70],[12,28]])translate([p[0],p[1],32.6])cube([5,4,4]);
}
module teac_boards(long_board=false) {
    translate([5,119,5])cube([134,78,1.6]);
    // Two visibly different sensor-PCB outlines, rather than duplicate rectangles.
    translate([0,0,31])linear_extrude(1.6)polygon(long_board?
      [[5,7],[21,7],[21,52],[51,52],[51,74],[40,82],[40,108],[33,113],[33,130],[10,130],[5,125]]:
      [[5,7],[21,7],[21,52],[51,52],[51,75],[44,81],[8,81],[5,76]]);
    translate([43,195,4.8])cube([64,11,1.6]);
}
module teac_contacts() {
    for(i=[0:23])translate([45+i*2.54,198,6.4])cube([1.4,7,.2]);
    for(y=[14:7:70])translate([12,y,32.7])difference(){cylinder(d=2.3,h=.2,$fn=12);translate([0,0,-.1])cylinder(d=1,h=.5,$fn=8);}
    for(p=[[43,70],[12,28]])translate([p[0],p[1],32.6])cylinder(d=3,h=.7,$fn=16);
}
module teac_coils() {
    translate([28,145,20])difference(){cube([16,24,15]);translate([3,-1,3])cube([10,26,9]);}
    for(y=[146:2:167])translate([27,y,20])cube([18,.5,15]);
}
module teac_power_socket() {
    translate([9,196,3])difference(){cube([23,10,10]);translate([2,4,2])cube([19,7,6]);}
}
module teac_traces(long_board=false) {
    for(i=[0:4])translate([7+i*2.2,10,32.65])cube([.5,42+i*2,.12]);
    for(i=[0:4])translate([7+i*2.2,52+i*2,32.65])cube([31-i*2,.5,.12]);
    if(long_board)for(i=[0:4])translate([10+i*2.4,82,32.65])cube([.5,42-i*3,.12]);
}

// Owner inserted-disk photos place media 7 mm deeper than the previous fit.
// Move the spindle, clamp and head contact system with the jacket; browser
// pivots/labels share that correction. The frame/guide-rail envelope is unchanged.
// Separate moving parts; pivots/travel are shared with the browser manifest.
module teac_spindle() { translate([0,7,0]) {
    // Large underside rotor visible through the carrier in owner 073718163.
    // It shares the emulated spindle phase, not a decorative static motor disc.
    translate([70,59,-1.5])difference(){
        cylinder(d=82,h=1,$fn=96);
        for(a=[0:120:359])translate([9*cos(a),9*sin(a),-.1])cylinder(d=1.6,h=1.3,$fn=12);
    }
    translate([70,59,-2])cylinder(d=8,h=2,$fn=32);

    translate([70,59,28])cylinder(d=26,h=9,$fn=40);
    translate([70,59,36.7])difference(){cylinder(d=16,h=.7,$fn=32);translate([0,0,-.1])cylinder(d=10,h=1,$fn=24);translate([0,-9,-.1])cube([9,18,1]);}
    translate([70,59,37])difference(){cylinder(d=12,h=3,$fn=24);translate([-1,-7,2])cube([2,14,2]);}

}
}
module teac_head_shape() { translate([0,7,0]) {
    translate([59,119,19])difference(){
        union(){cube([24,34,5]);translate([4,2,4])cube([16,24,4]);for(x=[-9,24])translate([x,4,0])cube([9,9,7]);}
        for(y=[5,28])translate([12,y,-1])cylinder(d=4,h=12,$fn=16);
    }
    translate([64,121,27])cube([14,10,3]);
    translate([48.5,125,19])cube([11,8,3]);
    // Bearing sleeves follow the head with clearance around the fixed guide rails.
    for(x=[46,92])translate([x,128,18])rotate([-90,0,0])difference(){
        cylinder(d=6,h=8,$fn=20);translate([0,0,-.1])cylinder(d=3.2,h=8.2,$fn=20);
    }
}
}
// Clearance extends through every carriage tab, not only the bearing sleeves.
module teac_head() {
    difference(){teac_head_shape();
        for(x=[46,92])translate([x,70,18])rotate([-90,0,0])cylinder(d=3.2,h=125,$fn=24);
    }
}
module teac_head_metal() { translate([0,7,0]) {
    translate([62,145,23])difference(){cube([18,6,1]);for(x=[3,15])translate([x,3,-1])cylinder(d=2,h=4,$fn=12);}
    for(x=[64,77])translate([x,148,24])screw(3,1);

    // Photo-visible carriage return spring; dimensions and winding estimated.
    for(i=[0:8])translate([66+i*.65,148,27])rotate([0,90,0])difference(){
        cylinder(d=3.2,h=.35,$fn=16);translate([0,0,-.1])cylinder(d=2.5,h=.6,$fn=16);
    }
    translate([64,148,26.8])cube([10,.4,.4]);
}
}
module teac_clamp() { translate([0,7,0]) {
    translate([66,46,34])cube([38,4,2]);
    translate([66,46,34])cube([8,18,1.4]);
    translate([70,59,32])difference(){cylinder(d=20,h=2,$fn=32);translate([0,0,-1])cylinder(d=10,h=4,$fn=24);}
}
}
module teac_components() {
    for(p=[[12,26],[43,70]])translate([p[0],p[1],33]){
        cylinder(d=3.8,h=3,$fn=16);for(a=[0,120,240])rotate([0,0,a])translate([1.8,0,-.4])cube([1,1,1]);
    }
    for(y=[36,43,54,63])translate([15,y,33])rotate([0,90,0])cylinder(d=1.8,h=5,$fn=12);
    for(p=[[14,134],[65,159],[95,175]])translate([p[0],p[1],6.6])cube([9,19,4]);
    for(y=[139:2:170])translate([113,y,12])cube([25,.55,23]);
}

// Cable housings surround the existing board fingers; hidden keying is provisional.
module teac_cable_plug(adapter=false) {
    if(!adapter){
    translate([47,199,3.2])difference(){
        cube([44,12,7]);translate([1,-1,1.3])cube([42,10,2.8]);
        translate([1,5,2.3])cube([42,9,1.5]);
    }
    translate([47,208,8.7])cube([44,3,1.5]);
    for(x=[47,88])translate([x,206,3.2])cube([3,5,7]);
    }
    // Four individual power entry wells, with the harness ending in the socket.
    translate([11,201,4])difference(){cube([19,8,7]);
        for(x=[2.5:4.5:16])translate([x,9,3.5])rotate([90,0,0])cylinder(d=2.7,h=7,$fn=16);}
}

// Separate upper load arm. Pivot and lift are illustrative until measured.
module teac_head_arm() { translate([0,7,0]) {
    translate([62,122,30])difference(){cube([18,15,1]);translate([2,2,-1])cube([14,11,3]);}
    translate([64,122,29])cube([14,10,1]);
    translate([69,133,30])cube([2,15,.5]);
}
}
// Exposed flexible magnetic medium, without its stationary paper jacket.
// Opaque magnetic disc rotates independently of its stationary jacket.
module teac_medium() { translate([0,7,0]) {
    translate([70,59,29.5])difference(){
        cylinder(r=65,h=.08,$fn=128);
        translate([0,0,-.1])cylinder(r=14.3,h=.3,$fn=48);
        translate([-24,6,-.1])cylinder(r=1.3,h=.3,$fn=16);
    }
}
}

// Owner photos 2026-10-13, scaled against nominal 133.35 mm jacket.
// Clean reference geometry: wear omitted; thickness and seams estimated.
module teac_diskette_jacket() { translate([0,7,0]) {
    translate([70,59,29.5])difference(){
        translate([-66.675,-66.675,-.5])cube([133.35,133.35,1.2]);
        translate([-65.675,-65.675,-.1])cube([131.35,131.35,.4]);
        translate([0,0,-1])cylinder(d=39,h=3,$fn=64);
        // Closed capsule opening, not a slot running to the edge.
        hull()for(y=[34,57])translate([0,y,-1])cylinder(d=12.5,h=3,$fn=32);
        translate([-24,6,-1])cylinder(d=6,h=3,$fn=24);
        translate([-68,-37,-1])cube([5,6.5,3]);
        for(x=[-14,14])translate([x,66.675,-1])cylinder(d=3,h=3,$fn=20);
        // Shallow folded-edge seams on the reverse, not through cuts.
        for(x=[-56,56])translate([x,-66,-.51])cube([.25,131,.08]);
        translate([-56,-56,-.51])cube([112,.25,.08]);
    }
}
}
module teac_diskette_label() { translate([0,7,0]) {
    translate([70,59,29.6])difference(){
        cylinder(d=34,h=.08,$fn=64);
        translate([0,0,-.1])cylinder(d=28.6,h=.3,$fn=64);
    }
    translate([70+10.5,59-62,30.22])linear_extrude(.08)
        offset(r=2)offset(delta=-2)square([51,36]);
}
}
// Separate white storage envelope actually used by the owner (not original).
// No ruler: overall dimensions and .2 mm paper thickness remain estimates.
module teac_storage_sleeve() {
    difference(){
        linear_extrude(2)offset(r=3)offset(delta=-3)square([139,145]);
        translate([.2,.2,.2])cube([138.6,145,1.6]);
        translate([-.1,125,1.8])cube([140,21,.3]);
    }
}

// Photo-referenced operating rod and eccentric fork. Hidden cam dimensions
// remain illustrative. Browser rotates this with the front lever, not the head.
module teac_latch_shaft() {
    translate([118,-8,32])rotate([-90,0,0])cylinder(d=3,h=60,$fn=24);
    translate([118,48,32])rotate([90,0,0])linear_extrude(2,center=true)
        hull(){circle(d=7,$fn=24);translate([5,0])circle(d=5,$fn=20);}
    translate([123,45,32])rotate([-90,0,0])cylinder(d=3,h=7,$fn=20);
}
// Clamp follower and longitudinal release rail lift the upper head clear of media.
module teac_release_rail() {
    translate([116,46,26])difference(){cube([12,8,5]);translate([1,-1,1])cube([10,10,3]);}
    translate([116,50,30])cube([2,4,5.2]);
    translate([98,50,34])cube([20,4,1.2]);
    translate([98,50,34])cube([3,105,1.2]);
    translate([78,145,34])cube([23,6,1.2]);
}

// Removable opaque write-protect sticker over the owner's jacket notch.
// TEAC FD-55 maintenance manual: covered notch inhibits writes.
module teac_protect_tab(){ translate([0,7,0]) {
 translate([70-66.8,59-38,29.5])union(){
  translate([0,0,.72])cube([8,9,.18]);
  translate([0,0,-.7])cube([8,9,.18]);
  translate([0,0,-.7])cube([.18,9,1.6]);
 }
}
}
