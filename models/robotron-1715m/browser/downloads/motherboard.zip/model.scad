include <source/model.scad>
part="download-only";
pcb_board="motherboard";
shape("logic-inductors");
shape("logic-boards");
shape("logic-chips");
shape("logic-pins");
shape("logic-connectors");
shape("logic-resistors");
shape("logic-ceramics");
shape("logic-electrolytics");
shape("logic-crystals");
shape("logic-passive-leads");
shape("logic-film");
shape("logic-pads");
shape("logic-solder");
shape("logic-connector-contacts");
shape("logic-mounts");
